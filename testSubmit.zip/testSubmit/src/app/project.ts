export class Project
{
    projectID: any;
    projectName: any;
    dateOfStart: any;
    teamSize: any;

    constructor()
    {
        this.projectID = 0;
        this.projectName = null;
        this.dateOfStart = null;
        this.teamSize = 0;
    }
}
