export class LoginViewModel
{
    UserName: string = "";
    Password: string = "";
}
